# OpenShelf — browser app

The fully working **browser** version of OpenShelf. Plain files, no build step.

- **Bundled classics** (Pride and Prejudice, Alice in Wonderland, a Sherlock Holmes story) read offline immediately.
- **Discover** searches Project Gutenberg's 75,000+ free books live and downloads them to your shelf.
- **Reader** with the held-page flip, four themes, font sizing, and saved progress.
- **Installable PWA** — "Add to Home Screen" gives it an app icon and offline use.

## Try it locally

Open `index.html` in a browser. The reader, flip, and bundled books all work.

> Two features need real hosting (HTTPS) rather than a `file://` open:
> the **install prompt / service worker** and **reliable book downloads**.

## Put it online (free, ~2 minutes)

Drag this `web/` folder onto any static host:

- **Netlify Drop** — https://app.netlify.com/drop
- **Cloudflare Pages** — https://pages.cloudflare.com
- **GitHub Pages** — push the folder, enable Pages

Then open the URL on your phone and choose **Add to Home Screen**.

## Files

| File | Purpose |
|------|---------|
| `index.html` | The entire app — UI, styles, reader, flip engine, Discover |
| `manifest.webmanifest` | PWA metadata + icons (installable) |
| `sw.js` | Service worker — caches the app shell for offline use |

The Android app in [`../android`](../android) reuses this exact `index.html`.
