# work.md — status, roadmap, and log

_Keep this file current. It is the single source of truth for "what's done and what's next."_

Last updated: 2026-07-13

---

## Current status

**Working now (browser + Android share this):**
- [x] **Read aloud** (text-to-speech) — play button in the reader, auto-advances pages,
      **off by default**, with a device-voice picker, speed control, and a "download
      better voices" hint. Uses the free Web Speech API (works on iOS/Android/desktop).
- [x] **EPUB support** — opens EPUB files (spine + chapters parsed to clean text).
- [x] **Open a book** — import an EPUB or TXT you were sent/downloaded, from Shelf or Settings.
- [x] **Settings page** — page-turn style, theme, font, read-aloud voice/speed, library
      import, sources, and about, all in one place (shared state with the in-book Aa menu).
- [x] **Language filter** (18 languages incl. Greek) and **35 categories** (cooking,
      fishing, gardening, farming, hunting, and more) with cleaner icon chips.
- [x] Downloaded/imported book text now **persists** (localStorage) so books survive
      reloads and open offline.
- [x] Reader with **held-page flip** — drag the page, move it back and forth, reverse
      across the spine mid-pull, flick to complete. 3D perspective so the sheet stands up.
- [x] Other page turns: Slide, Fade, Instant.
- [x] Four themes: Sepia, Paper, Dusk, Night.
- [x] Font-size control; layout re-paginates and keeps your place.
- [x] Automatic pagination via CSS multicolumn (one column = one page).
- [x] Tap zones (back / menu / next), swipe, mouse-drag, arrow keys, spacebar.
- [x] **Shelf** with covers and per-book progress.
- [x] **Discover** — live search of Project Gutenberg via Gutendex; download to shelf.
- [x] Graceful fallback when a title can't be fetched cross-origin (opens on Gutenberg).
- [x] 3 bundled public-domain books that work fully offline.
- [x] Saved reading position + settings (localStorage, memory fallback).
- [x] Installable **PWA** (manifest + service worker, offline app shell).
- [x] **Android app** scaffold (Capacitor) reusing the web reader.
- [x] Android native extras: volume-key page turns, themed status bar, hardware back.

**Project set up:**
- [x] Split into `web/` and `android/` as two separate apps.
- [x] `README.md`, `rules.md`, `work.md`, `autopilot.md` in place.
- [x] **CI** (`.github/workflows/build.yml`): builds the Android APK as a downloadable
      artifact and deploys the web app to GitHub Pages on every push. `.gitignore` added.

---

## Backlog (do these next, roughly in order)

### Reading
- [ ] **Cover images on the shelf** for downloaded Gutenberg books (Gutendex gives a JPEG URL).
- [ ] **Bookmarks + notes** list per book.
- [ ] **Table of contents / chapter jump.**
- [ ] Better chapter detection when parsing plain text (roman numerals, "PART", etc.).
- [ ] **EPUB support** (many Gutenberg books are cleaner as EPUB than plain text).
- [ ] Remember last-read book and offer "Continue reading" on the shelf.

### Downloads / offline
- [ ] Cache downloaded book text in **IndexedDB** so big books survive reloads and go offline.
- [ ] Download progress + a small queue.
- [ ] Optional tiny **CORS proxy** (or serverless function) so any Gutenberg title fetches
      in the browser build. (Native app doesn't need this.)

### Sources
- [ ] Add **Standard Ebooks** and **Wikisource** as browsable sources (OPDS where possible).
- [ ] "Add a source" screen: paste an OPDS catalog URL.

### Android
- [ ] App icon + splash art (replace the placeholder SVG icon).
- [ ] Confirm volume-key plugin wiring on a real device.
- [ ] Play Store listing assets (screenshots, description).

### Polish / quality
- [ ] Smooth the reversal hand-off at the spine (tiny jitter near progress 0).
- [ ] Optional **WebGL soft page-curl** for paper that bends, not just rotates (heavier;
      guard for low-end devices). Keep CSS flip as the default/fallback.
- [ ] Light automated tests for the paginator and the parser.
- [ ] iOS app target (Capacitor iOS) — needs a Mac + Apple Developer account ($99/yr).

---

## Known issues / honest limits

- **Cross-origin full-text fetch (browser only):** some Gutenberg titles block direct
  browser download. Handled with a fallback link today; fully solved by IndexedDB +
  a small proxy, or by using the Android/native app.
- **Gutendex uptime is best-effort.** Discover shows a calm message if it's unreachable;
  bundled books keep working.
- **Service worker + install** need HTTPS hosting; they don't run from a `file://` open.
- **Reversal jitter:** dragging the page exactly back to the spine can flicker slightly.

---

## Change log

- **2026-07-13** — Turn speed is now a real slider (Fast\u2013Slow), in Settings and the
  Aa menu, and it applies in EVERY theme (was a value-scope bug that only worked on
  default). Page-turn base duration slowed (460ms \u00d7 slider) so even the fastest
  setting is calmer. Read-aloud fixed: voices now load with a retry loop for Android
  WebViews (which report the list a moment late), so it no longer falsely says
  \u201Cnot available\u201D; if speech genuinely can't start, a clear message points to
  the device Text-to-speech settings.

- **2026-07-13** — PDF reading + URL adder + all 15 sources. PDF is now a readable
  format (pdf.js) for imported files and online PDFs. New "Add a book from a link"
  button on Shelf and Settings: paste any direct .txt/.epub/.pdf URL and it opens.
  Discover Source menu now lists 15 libraries: 7 with in-app search (Gutenberg,
  Standard Ebooks, Internet Archive, Open Library, Wikisource, Wikibooks, Google Books)
  and 8 catalogue links (DOAB, OpenStax, Open Textbook Library, National Academies
  Press, HathiTrust, arXiv, ManyBooks, Smashwords) that open the library and hand off
  to the URL adder. SW cache v4. DRM was not added: the supplied DRM zips are
  de-protection tools; integrating them is illegal and against the project rules, so
  they were left untouched. Amazon/Libby/Hoopla/cloudLibrary remain external links
  (their books are DRM-locked).

- **2026-07-13** — ALL SOURCES + ICON release. Discover now has a Source menu with four
  live libraries: Project Gutenberg, Standard Ebooks (downloads real EPUBs), Internet
  Archive (public scanned texts), and Wikisource (many languages incl. Greek). Search
  requests now race through relay mirrors too, so a slow library no longer dead-ends
  Discover. App icon is the open tome — all Android launcher densities + adaptive icon
  wired in via a Capacitor sync hook, plus PWA icons (SW cache v3). Saved REQUIREMENTS.md
  master checklist. Sources tab now lists everything as Connected.

- **2026-07-13** — Added a Turn speed setting (Fast / Medium / Slow) in Settings and
  in the in-book Aa menu. Fast is the previous behaviour and the default; Medium and
  Slow stretch the flip, slide, and fade animations.

- **2026-07-13** — Reader engine rebuilt (Android-first). The multicolumn/segment
  approach caused misaligned half-pages and a silent freeze that left a stale
  "Downloading…" screen; both are gone. New engine measures and builds each page
  exactly (word-accurate splits, chapter headings never stranded), opens instantly,
  counts pages in the background, restores position by reading progress (survives
  font-size changes). Verified by an automated test: a simulated 726-page novel
  paginates with every word present in order and zero overflow. Added a crash guard:
  any reader error now shows a readable message + toast instead of freezing. Opening
  a book always clears the previous screen first.
- **2026-07-13** — Speed + fix release: (1) downloads race all sources in parallel
  (first good response wins) instead of one-at-a-time — big books fetch in seconds;
  (2) segmented lazy pagination — even a 500-page novel opens instantly and counts
  pages in the background, no more freeze on open or reopen; (3) selected buttons in
  Default/Beige/Sky now use two darker shades of their own colour — metallic gold only
  in the Gold theme; (4) Discover search has a 10s timeout and a Retry button instead
  of an endless spinner; (5) corrected .github/workflows/build.yml (web job contents
  permission + Pages enablement:true + Node 22) so the web deploy finally works.
- **2026-07-13** — Gold theme rebuilt to the approved all-gold mockup: light gold
  gradient background, gold chips/bars/sheets with dark bronze engraved text, metallic
  gold selected state with cream inner outline. Covers keep normal colours; reading
  pages keep the normal page themes. Also applied Kindle-style reading layout app-wide:
  the text column is capped (~620px), centered, with real margins — no more
  edge-to-edge lines on tablets.
- **2026-07-13** — Added a 4th App-colour: an all-**Gold** theme (dark gold surfaces,
  metallic gold selected/primary buttons). Default green, Beige, and Sky blue are
  unchanged. Gold styling applies only to the Gold theme.
- **2026-07-13** — Visual pass: cushioned "pillow" styling on all buttons, chips,
  segments, and swatches (soft bevel + gradient + shadow) matching the weather-app look;
  bronze-gold gradient for the selected/primary state. Added an **App colour** chooser in
  Settings (Default green / Beige / Sky blue) driven by CSS-variable palettes, with the
  current look as the highlighted default. Reading page kept flat for legibility.
- **2026-07-13** — Big update: read-aloud with device-voice picker + speed (off by
  default); EPUB support (JSZip) and "Open a book" import for EPUB/TXT files; a full
  Settings page (page-turn style, theme, font, voices, sources, about) sharing state
  with the in-book Aa menu; cleaner icon category chips; persistent per-book text cache
  so downloads/imports survive reloads and work offline. SW cache bumped to v2.
- **2026-07-13** — Added a language filter (English, Greek, French, German, Spanish,
  Italian, Latin, Dutch, and more — 18 options) and 35 browsable categories (cooking,
  fishing, gardening, farming, history, science, poetry, children, and many more) via
  Gutendex topic search. Typing any word now falls back to a subject search, so
  arbitrary topics like "beekeeping" still find books. Verified Gutenberg's Greek
  collection (Modern Greek literature + ancient/translated works).
- **2026-07-13** — Hardened downloads for all devices: 5 fallback mirrors, a live
  "trying mirror X of Y" indicator so it never looks frozen, and honest source-status
  badges (Connected vs Coming soon) on the Sources tab. Confirmed the research: Gutenberg
  already covers the full public-domain catalog; other sites duplicate it, are DRM-locked,
  dead, or piracy.
- **2026-07-13** — Fixed book downloads. Discover downloads now try every text format
  and fall back through public CORS relays when the browser blocks a direct fetch;
  the Android app uses native HTTP (CapacitorHttp) to bypass CORS entirely. Failures
  now show the "open on Project Gutenberg" fallback instead of a blank page. HTML
  editions are stripped to clean text.
- **2026-07-13** — Added CI: `.github/workflows/build.yml` builds the Android debug APK
  (downloadable artifact) and deploys `web/` to GitHub Pages. Consolidated two earlier
  split workflows into one; added `.gitignore`.
- **2026-07-13** — Held-page flip (two-way tracking, spine reversal, flick-to-turn) +
  3D perspective fix. Reorganized into `web/` and `android/` as two apps. Added
  `README.md`, `rules.md`, `work.md`, `autopilot.md`. Android Capacitor project with
  native volume-key/status-bar/back-button layer.
- **2026-07-13** — First real app: PWA reader with bundled books, live Gutendex
  Discover, themes, font sizing, progress, tap/swipe/keyboard turns.

## Build / CI

- [x] **GitHub Actions: Android APK** — `.github/workflows/android.yml` builds a debug
      APK on every push and uploads it as an artifact. Compiles the Capacitor project
      end to end (npm install → sync web → `cap add android` → `gradlew assembleDebug`).
- [x] **GitHub Actions: Pages** — `.github/workflows/pages.yml` deploys `web/`.
- [x] `.gitignore` excludes `node_modules/`, the generated `android/android/` native
      project, and build outputs — the native project is regenerated by CI.
- [ ] Optional: signed **release** APK/AAB via keystore secrets for Play Store upload.
- [ ] Optional: attach the APK to a GitHub **Release** on version tags.
