# rules.md — the rules OpenShelf lives by

These are **hard constraints**. Anyone (human or AI) working on OpenShelf follows them.
If a request conflicts with a rule here, stop and flag it rather than breaking the rule.

---

## 1. Legal rules (highest priority — never bend these)

1. **Public-domain and freely-licensed books only.** Allowed sources: Project Gutenberg
   (via the Gutendex API), Standard Ebooks, Internet Archive *public-domain* texts,
   Wikisource, and other clearly free/open catalogs.
2. **No pirate or "shadow" libraries.** Never add, link, scrape, or integrate sources
   that distribute in-copyright books without permission.
3. **Never circumvent DRM.** No stripping, decrypting, or working around any copy
   protection. (This is the single thing that makes many "free book" apps illegal.)
4. **Respect source terms.** For Project Gutenberg: use the official API/feeds, don't
   hammer servers, and don't use the "Project Gutenberg" trademark in the app's name
   or branding. Cache results and be gentle.
5. **Country notice.** Public-domain status varies by country. The app shows a plain
   "status varies by country" note; keep it.
6. **No Amazon/Kindle trademarks.** The app can *feel* like a Kindle but must not use
   "Kindle", Amazon marks, or Amazon's proprietary fonts (e.g. Bookerly). Use open
   fonts (Literata) instead.
7. Not legal advice. If OpenShelf ever becomes a paid/commercial product, get an IP
   lawyer to review before launch.

## 2. Product rules

1. **Reading comes first.** The reader is the heart of the app; keep it fast, calm,
   and legible. Nothing decorative gets in the way of the words.
2. **The held-page flip is the signature.** Default page turn is the realistic
   drag-to-flip. Slide / Fade / Instant remain available as options.
3. **Offline by default.** Bundled books must always work with no network. Downloaded
   books stay readable offline.
4. **Own your library.** No account required to read. No ads. No tracking of what
   people read beyond what's needed to save their place on their own device.
5. **Accessible.** Keyboard navigation, respects reduced-motion, readable contrast in
   every theme, sensible font sizes.

## 3. Engineering rules

1. **One reading engine.** The reader lives in `web/index.html`. The Android app
   *packages* it — it does not fork it. Fix bugs once, in the shared app.
2. **No build step for the web app.** It must stay openable as plain files. No bundler
   required to run it.
3. **Vanilla, dependency-light.** The reader uses plain HTML/CSS/JS — no framework.
   Bootstrap/CDN use is allowed only where it clearly earns its place and is cached.
4. **Storage is best-effort.** Use `localStorage` with an in-memory fallback; never let
   storage failure break reading.
5. **Fail gracefully.** If the online library or a download fails, show a calm message
   and a fallback (e.g. open on Project Gutenberg) — never a dead end or a raw error.
6. **Two-way, honest status.** Don't claim something works that hasn't been verified
   (e.g. cross-origin full-text fetch). Note known limits in `work.md`.
7. **Keep the docs live.** Every meaningful change updates `work.md`.

## 4. Naming / branding

- Placeholder product name: **OpenShelf**. Android `appId`: `com.openshelf.reader`.
- Palette: moss `#202A1E`, sepia `#F4EAD3`, gilt `#C8A24B`, ribbon `#A93B44`, green `#2E5339`.
- Type: Fraunces (display), Literata (reading), Inter (UI).
