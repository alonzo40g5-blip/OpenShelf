# OpenShelf

A free reader for **public-domain books**, with a page-turning experience that
feels like holding a real book. Search 75,000+ classics from Project Gutenberg,
download them, and read offline.

> **OpenShelf** is a placeholder name.

## Two apps, one shared reader

| App | Folder | What it is |
|-----|--------|-----------|
| **Browser** | [`web/`](web) | A fully working web app / installable PWA. Works on iPhone, iPad, Android, and desktop. No build step. |
| **Android** | [`android/`](android) | An installable Android app that packages the same reader and adds native volume-key page turns. |

Both share the **same reading engine** (the `web/index.html` app), so the held-page
flip and everything else stay identical. The Android app layers native-only extras on top.

## Start here

- Want to read right now? → open [`web/index.html`](web/index.html)
- Want it live on your phone? → [`web/README.md`](web/README.md) (drag-and-drop hosting)
- Want the Android app? → [`android/README.md`](android/README.md)

## Project docs

| File | Read it for |
|------|-------------|
| [`rules.md`](rules.md) | The hard rules — legal, product, and engineering. **Non-negotiable.** |
| [`work.md`](work.md) | Current status, roadmap, task board, and change log. |
| [`autopilot.md`](autopilot.md) | How to continue the project autonomously, step by step. |

## The short legal story

Everything shipped is **public domain** or freely licensed — Project Gutenberg
(via the Gutendex API), Standard Ebooks, Internet Archive public-domain texts,
Wikisource. No pirate/"shadow" libraries, no DRM circumvention. Public-domain
status varies by country, and the app says so. Full detail in [`rules.md`](rules.md).

## Build on GitHub (automatic)

This repo builds itself with GitHub Actions — no local setup needed:

- **`.github/workflows/android.yml`** — on every push, compiles the **Android APK**
  and uploads it. Get it from the run's **Artifacts** (`openshelf-debug-apk`).
- **`.github/workflows/pages.yml`** — publishes the **web app** to GitHub Pages
  (enable *Settings → Pages → Source: GitHub Actions* once).

### Quick start
1. Create a new GitHub repo and push these files (or upload the zip's contents).
2. Open the **Actions** tab — the Android build runs automatically.
3. Download the APK from the finished run's **Artifacts**, copy it to your phone,
   and install (enable "install unknown apps" if prompted).

The APK is an unsigned **debug** build — perfect for installing on your own device.
For the Play Store, add a signing keystore as repo secrets and build a release; see
the note at the bottom of `android.yml`.
