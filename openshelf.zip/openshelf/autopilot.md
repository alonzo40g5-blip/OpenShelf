# autopilot.md — how to continue OpenShelf on your own

This file tells a developer **or an AI agent** how to pick up OpenShelf and keep
building it safely, without needing the original context. Follow it top to bottom.

---

## 0. Before doing anything

1. Read [`rules.md`](rules.md) in full. Those constraints are **non-negotiable**
   (legal, product, engineering). If a task would break one, **stop and flag it**.
2. Read [`work.md`](work.md). It holds current status and the ordered backlog.
3. Skim the project map below so you know where things live.

## 1. Project map

```
openshelf/
├─ README.md          overview + how to run both apps
├─ rules.md           the hard rules (read first)
├─ work.md            status, roadmap, task board, change log
├─ autopilot.md       this file
├─ web/               THE BROWSER APP (canonical reader lives here)
│  ├─ index.html      entire app: UI + styles + reader + flip engine + Discover
│  ├─ manifest.webmanifest
│  └─ sw.js           service worker (offline shell)
└─ android/           THE ANDROID APP (packages web/ via Capacitor)
   ├─ www/            copy of web/ + native.js (native-only extras)
   ├─ capacitor.config.json
   ├─ package.json
   ├─ scripts/sync-web.sh   copies web/ → android/www
   └─ README.md
```

**Golden rule:** the reader is edited in **`web/index.html` only**. The Android app
reuses it; never fork the reader.

## 2. The work loop

Repeat this cycle:

1. **Pick** the top unchecked item in `work.md` → "Backlog" (respect the order unless a
   dependency says otherwise).
2. **Check it against `rules.md`.** If it conflicts, skip and flag; pick the next item.
3. **Implement** it in the right place:
   - Reading/UI/flip/Discover → `web/index.html`.
   - Android-only behaviour (needs the device) → `android/www/native.js` + a Capacitor
     plugin, wired through `capacitor.config.json`.
   - Never add a dependency to the web reader unless `rules.md` §3 allows it.
4. **Verify** against the checklist in §3 below.
5. **Propagate to Android** if you touched the web app: run `npm run sync` in `android/`.
6. **Update `work.md`**: tick the item, add a dated line to the change log, and record any
   new known issue.
7. Go to 1.

Make small, reviewable changes. One backlog item per pass where possible.

## 3. Definition of done (verify every change)

- [ ] Reading still works with **no network** using the bundled books.
- [ ] The **held-page flip** still feels right: drag both ways, reverse at the spine,
      flick to complete; Slide/Fade/Instant still work.
- [ ] All four **themes** and **font sizes** still render and re-paginate correctly.
- [ ] **Keyboard** (arrows/space/esc) and **reduced-motion** still behave.
- [ ] Nothing violates `rules.md` (no non-free sources, no DRM, no Kindle/Amazon marks).
- [ ] If Discover/download changed: a failed fetch still shows a **calm fallback**, not an error.
- [ ] `work.md` updated.

## 4. How to run / build

**Browser app**
- Open `web/index.html` to test locally.
- To get PWA install + reliable downloads, host `web/` on any static HTTPS host
  (Netlify Drop, Cloudflare Pages, GitHub Pages). See `web/README.md`.

**Android app** (from `android/`)
```bash
npm install
npm run add-android   # first time: creates the native project
npm run open          # opens Android Studio → press Run
# after editing web/: npm run sync && npm run open
```
Details in `android/README.md`.

## 5. Guardrails for autonomous work

- **Legal first.** Never add a source that isn't clearly public-domain/free. Never touch DRM.
- **Don't break offline.** Bundled books are the safety net; keep them working.
- **Don't fork the reader.** One engine in `web/index.html`.
- **Prefer graceful degradation.** A missing plugin or a dead API should never brick the app.
- **When unsure, write it down** in `work.md` under "Known issues" and flag it rather than
  guessing in a way that could mislead users about what works.

## 6. Good first tasks (safe, high-value)

1. Cover images on the shelf for downloaded books (Gutendex provides a JPEG URL).
2. Cache downloaded text in IndexedDB (fixes reloads + full offline for big books).
3. Bookmarks list per book.
4. Replace the placeholder Android icon/splash with real art.

Each is already listed in `work.md`; tick them off as you go.
