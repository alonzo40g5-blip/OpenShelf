# OpenShelf — Everything requested (master list)

1.  Free ebook reader app, public-domain books, reads like a Kindle — ✅
2.  Realistic held-page flip: drag the page back and forth like paper — ✅
3.  Works on phone, tablet, PC, BlueStacks, iPhone/iPad browser — ✅ (APK + web build)
4.  Books download on every device — ✅ (parallel source racing; native HTTP on Android)
5.  ALL categories: cooking, fishing, gardening, anything — ✅ (35 chips + any word searches subjects)
6.  Greek and other languages — ✅ (18-language filter incl. Greek)
7.  Read-aloud that ONLY starts when pressed — ✅ (device-voice picker + speed; off by default)
8.  A Settings page — ✅
9.  Open a book you were sent / downloaded (EPUB or TXT) — ✅
10. Cushioned, bulging buttons — ✅
11. App colours: Default green, Beige, Sky untouched; ONE all-gold theme; other themes select
    with two darker shades of their own colour (no bronze) — ✅
12. Kindle-like centered, readable text with real margins — ✅
13. Turn-speed toggle: Fast (current) / Medium / Slow — ✅
14. Fast downloads — ✅
15. No freezing on big books; correct pages; resume where you left off — ✅ (rebuilt engine,
    verified by automated test)
16. Web version on GitHub Pages — ⚠ one-time switch in GitHub: Settings → Pages →
    Source: GitHub Actions, then re-run. Everything on our side is done.
17. App icon = the open tome image — ✅ (this update)
18. ALL ebook sources added, not just Gutenberg — ✅ (this update: Project Gutenberg,
    Standard Ebooks, Internet Archive, Wikisource — a Source picker in Discover)
19. Discover must not fail with a dead "couldn't reach" — ✅ (this update: retries through
    relay mirrors before giving up; Retry button stays)

Rules that always apply: public-domain only, no DRM, no piracy sources, no Kindle/Amazon
branding, one shared reader engine, Android APK is the primary target.
