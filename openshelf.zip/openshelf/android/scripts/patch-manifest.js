// Injects the TTS_SERVICE <queries> the text-to-speech plugin needs (Android 11+),
// and applies our launcher icons. Runs after `npx cap sync`.
const fs = require("fs");
const path = require("path");
const man = path.join(__dirname, "..", "app", "src", "main", "AndroidManifest.xml");
try {
  let x = fs.readFileSync(man, "utf8");
  if (x.indexOf("android.intent.action.TTS_SERVICE") === -1) {
    const q = '    <queries>\n        <intent>\n            <action android:name="android.intent.action.TTS_SERVICE" />\n        </intent>\n    </queries>\n';
    // insert just before </manifest>
    x = x.replace(/<\/manifest>/, q + "</manifest>");
    fs.writeFileSync(man, x);
    console.log("AndroidManifest: TTS queries added");
  } else {
    console.log("AndroidManifest: TTS queries already present");
  }
} catch (e) {
  console.log("patch-manifest skipped:", e.message);
}
