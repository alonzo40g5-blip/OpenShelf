// postsync.js — runs automatically after `npx cap sync android`
// (wired via the "capacitor:sync:after" hook in package.json).
//
// Installs everything the generated native project needs that Capacitor
// doesn't know about:
//   1) launcher icons (resources/android-res -> app/src/main/res)
//   2) vendored native plugins + MainActivity (native-src -> app java tree)
//      — volume-key page turns and native read-aloud, with NO third-party
//        npm plugins, so `npm install` can never fail on them again
//   3) the <queries> entry AndroidManifest needs so the app can see the
//      device's TTS engine on Android 11+
//
// Exits non-zero on a real problem so CI fails loudly instead of shipping
// a half-configured APK.

const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");        // openshelf/android (Capacitor project root)
const proj = path.join(root, "android");        // generated native Android project

function fail(msg) {
  console.error("postsync: ERROR — " + msg);
  process.exit(1);
}

if (!fs.existsSync(path.join(proj, "app"))) {
  fail("native project not found at android/android — run `npx cap add android` first");
}

function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, entry.name);
    const d = path.join(dst, entry.name);
    if (entry.isDirectory()) copyDir(s, d);
    else fs.copyFileSync(s, d);
  }
}

// ---- 1) launcher icons -----------------------------------------------------
const iconSrc = path.join(root, "resources", "android-res");
if (fs.existsSync(iconSrc)) {
  copyDir(iconSrc, path.join(proj, "app", "src", "main", "res"));
  console.log("postsync: launcher icons applied");
} else {
  console.log("postsync: no resources/android-res folder — keeping default icons");
}

// ---- 2) vendored native sources -------------------------------------------
const nativeSrc = path.join(root, "native-src");
if (!fs.existsSync(nativeSrc)) {
  fail("native-src/ is missing — MainActivity + plugins can't be installed");
}
const pkgDir = path.join(proj, "app", "src", "main", "java", "com", "openshelf", "reader");
if (!fs.existsSync(pkgDir)) {
  fail("expected package dir not found: " + pkgDir + " (appId changed? update postsync.js + native-src package lines)");
}
let installed = 0;
for (const f of fs.readdirSync(nativeSrc)) {
  if (f.endsWith(".java")) {
    fs.copyFileSync(path.join(nativeSrc, f), path.join(pkgDir, f));
    console.log("postsync: installed " + f);
    installed++;
  }
}
if (installed === 0) fail("no .java files found in native-src/");

// ---- 3) AndroidManifest: TTS <queries> (Android 11+ package visibility) ----
const manifest = path.join(proj, "app", "src", "main", "AndroidManifest.xml");
let xml = fs.readFileSync(manifest, "utf8");
if (xml.indexOf("android.intent.action.TTS_SERVICE") === -1) {
  const q =
    "    <queries>\n" +
    "        <intent>\n" +
    "            <action android:name=\"android.intent.action.TTS_SERVICE\" />\n" +
    "        </intent>\n" +
    "    </queries>\n";
  xml = xml.replace(/<\/manifest>\s*$/, q + "</manifest>\n");
  fs.writeFileSync(manifest, xml);
  console.log("postsync: TTS <queries> added to AndroidManifest.xml");
} else {
  console.log("postsync: TTS <queries> already present");
}

console.log("postsync: done");
