#!/usr/bin/env bash
# Copy the canonical web reader (../web) into this app's www/ folder.
# native.js lives only here and is preserved, then re-linked into index.html.
set -euo pipefail

HERE="$(cd "$(dirname "$0")/.." && pwd)"
WEB="$HERE/../web"
WWW="$HERE/www"

echo "Syncing shared reader:  $WEB  ->  $WWW"

# copy shared assets (keep native.js, which only exists in the app)
cp "$WEB/index.html"          "$WWW/index.html"
cp "$WEB/manifest.webmanifest" "$WWW/manifest.webmanifest"
cp "$WEB/sw.js"               "$WWW/sw.js"
cp "$WEB/icon-192.png"        "$WWW/icon-192.png" 2>/dev/null || true
cp "$WEB/icon-512.png"        "$WWW/icon-512.png" 2>/dev/null || true

# re-inject the native enhancements reference into the app's index.html
if ! grep -q "native.js" "$WWW/index.html"; then
  # add before </body>
  sed -i 's#</body>#<script src="native.js"></script>\n</body>#' "$WWW/index.html"
fi

echo "Done. Now run:  npx cap sync android"
