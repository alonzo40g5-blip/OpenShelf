# OpenShelf — Android app

This is the **Android** build of OpenShelf. It packages the shared reader from
[`../web`](../web) into a real installable Android app (an `.apk`/`.aab`) and adds
native touches a plain website can't do:

- **Volume keys turn the page**
- **Status bar** colour follows the reading theme
- **Hardware Back** closes the open book/menu before exiting

The reading experience — including the held-page flip — is the *same engine* as the
browser version, so both apps always behave identically. Native extras live in
[`www/native.js`](www/native.js) and are ignored by the browser build.

---

## What you need (one-time)

1. **Node.js 18+** — https://nodejs.org
2. **Android Studio** (includes the Android SDK) — https://developer.android.com/studio
3. A phone with USB debugging on, or an emulator from Android Studio.

> You do **not** need a Mac. Android builds work on Windows, macOS, or Linux.

---

## Build it

From this `android/` folder:

```bash
npm install            # fetch Capacitor + plugins
npm run add-android    # copies the web app in and creates the native android/ project
npm run open           # opens the project in Android Studio
```

Then in Android Studio press **Run ▶** to install on your phone/emulator.

To make a shareable file: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
For the Play Store, use **Build → Generate Signed Bundle / APK** and upload the `.aab`.

## After changing the reader

Whenever you edit the shared app in `../web`, re-sync and re-run:

```bash
npm run sync           # pull latest web reader into the app
npm run open           # (or just press Run again in Android Studio)
```

---

## Notes

- `appId` is `com.openshelf.reader` (change it in `capacitor.config.json` before publishing).
- Publishing to Google Play needs a one-time **$25** developer account.
- Everything the app ships is public-domain or freely licensed — see [`../rules.md`](../rules.md).
- Volume-key page turns and native read-aloud are **vendored plugins** that live in this
  repo (`native-src/*.java`, installed into the generated project by `scripts/postsync.js`
  after every `npx cap sync android`). There are **no third-party npm plugins** — only the
  official `@capacitor/*` packages — so `npm install` can't fail on a mismatched community
  plugin version. If a plugin is somehow missing at runtime, the app still works and pages
  still turn by tap/swipe.
