package com.openshelf.reader;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Minimal in-tree replacement for the "@capacitor-community/volume-buttons"
 * npm plugin (which we no longer depend on). Exposes the same JS surface the
 * app's native.js uses:
 *
 *   Capacitor.Plugins.VolumeButtons.watchVolume({...}, cb) // cb({direction})
 *   Capacitor.Plugins.VolumeButtons.clearWatch()
 *   Capacitor.Plugins.VolumeButtons.setSuppressVolume({enabled})
 *
 * MainActivity forwards KEYCODE_VOLUME_UP/DOWN here. When "suppress" is on
 * (a book is open), the key becomes a page turn and the system volume UI is
 * blocked; when off, volume keys behave normally.
 */
@CapacitorPlugin(name = "VolumeButtons")
public class VolumeButtonsPlugin extends Plugin {

    static volatile VolumeButtonsPlugin instance;

    private PluginCall watchCall;
    private volatile boolean suppress = false;

    @Override
    public void load() {
        instance = this;
    }

    @PluginMethod(returnType = PluginMethod.RETURN_CALLBACK)
    public void watchVolume(PluginCall call) {
        Boolean d = call.getBoolean("disableSystemVolumeHandler", Boolean.FALSE);
        suppress = Boolean.TRUE.equals(d);
        call.setKeepAlive(true);
        watchCall = call;
    }

    @PluginMethod
    public void clearWatch(PluginCall call) {
        watchCall = null;
        suppress = false;
        call.resolve();
    }

    @PluginMethod
    public void setSuppressVolume(PluginCall call) {
        Boolean e = call.getBoolean("enabled", Boolean.FALSE);
        suppress = Boolean.TRUE.equals(e);
        call.resolve();
    }

    /** True while volume keys should be swallowed instead of changing volume. */
    boolean isCapturing() {
        return watchCall != null && suppress;
    }

    /**
     * Called by MainActivity on the UI thread.
     * @return true if the key event was consumed (page turn), false to let the
     *         system handle it (normal volume change).
     */
    boolean handleVolumeKey(boolean up) {
        PluginCall c = watchCall;
        if (c == null || !suppress) {
            return false;
        }
        JSObject data = new JSObject();
        data.put("direction", up ? "up" : "down");
        c.resolve(data); // keepAlive call: may be resolved repeatedly
        return true;
    }
}
