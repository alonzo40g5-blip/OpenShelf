package com.openshelf.reader;

import android.os.Bundle;
import android.view.KeyEvent;
import com.getcapacitor.BridgeActivity;

/**
 * OpenShelf MainActivity.
 *
 * Installed over the Capacitor-generated MainActivity by scripts/postsync.js.
 * Registers the two vendored plugins (no third-party npm plugins needed) and
 * forwards hardware volume keys to VolumeButtonsPlugin so the reader can turn
 * pages with them.
 */
public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // Must be registered before super.onCreate() (Capacitor 3+ requirement)
        registerPlugin(TextToSpeechPlugin.class);
        registerPlugin(VolumeButtonsPlugin.class);
        super.onCreate(savedInstanceState);
    }

    private boolean isVolumeKey(int keyCode) {
        return keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (isVolumeKey(keyCode)) {
            VolumeButtonsPlugin p = VolumeButtonsPlugin.instance;
            if (p != null && p.handleVolumeKey(keyCode == KeyEvent.KEYCODE_VOLUME_UP)) {
                return true; // consumed: page turn instead of volume change
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (isVolumeKey(keyCode)) {
            VolumeButtonsPlugin p = VolumeButtonsPlugin.instance;
            if (p != null && p.isCapturing()) {
                return true; // swallow the matching key-up as well
            }
        }
        return super.onKeyUp(keyCode, event);
    }
}
