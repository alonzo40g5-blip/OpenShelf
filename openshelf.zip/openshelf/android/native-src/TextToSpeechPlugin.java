package com.openshelf.reader;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Minimal in-tree replacement for the "@capacitor-community/text-to-speech"
 * npm plugin (which we no longer depend on). Speaks through the device's own
 * TTS engine (Samsung / Google voices). JS surface used by native.js:
 *
 *   Capacitor.Plugins.TextToSpeech.speak({text, lang, rate, pitch, volume,
 *                                         voice, utteranceId})
 *       -> resolves when the utterance FINISHES ({interrupted:true} if it was
 *          cancelled/flushed), rejects if speech cannot start.
 *   Capacitor.Plugins.TextToSpeech.stop()
 *   Capacitor.Plugins.TextToSpeech.getSupportedVoices() -> {voices:[...]}
 *
 * Emits a "start" event ({utteranceId}) when audio actually begins, so the
 * web reader's onstart handler works.
 */
@CapacitorPlugin(name = "TextToSpeech")
public class TextToSpeechPlugin extends Plugin {

    private static final int PENDING = 0;
    private static final int READY = 1;
    private static final int FAILED = 2;

    private TextToSpeech tts;
    private final Object lock = new Object();
    private int state = PENDING;
    private final List<Runnable> queued = new ArrayList<>();
    private final Map<String, PluginCall> inFlight = new HashMap<>();
    private int counter = 0;

    @Override
    public void load() {
        tts = new TextToSpeech(getContext(), status -> {
            List<Runnable> run;
            synchronized (lock) {
                state = (status == TextToSpeech.SUCCESS) ? READY : FAILED;
                run = new ArrayList<>(queued);
                queued.clear();
            }
            for (Runnable r : run) {
                r.run();
            }
        });
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {
                JSObject ev = new JSObject();
                ev.put("utteranceId", utteranceId);
                notifyListeners("start", ev);
            }

            @Override
            public void onDone(String utteranceId) {
                PluginCall c = takeCall(utteranceId);
                if (c != null) {
                    c.resolve(new JSObject());
                }
            }

            @Override
            public void onStop(String utteranceId, boolean interrupted) {
                PluginCall c = takeCall(utteranceId);
                if (c != null) {
                    JSObject r = new JSObject();
                    r.put("interrupted", true);
                    c.resolve(r);
                }
            }

            @Override
            @SuppressWarnings("deprecation")
            public void onError(String utteranceId) {
                PluginCall c = takeCall(utteranceId);
                if (c != null) {
                    c.reject("The speech engine reported an error");
                }
            }

            @Override
            public void onError(String utteranceId, int errorCode) {
                onError(utteranceId);
            }
        });
    }

    private PluginCall takeCall(String id) {
        synchronized (lock) {
            return inFlight.remove(id);
        }
    }

    /** Settle every in-flight utterance as interrupted (used by flush/stop). */
    private void settleAllInterrupted() {
        List<PluginCall> calls;
        synchronized (lock) {
            calls = new ArrayList<>(inFlight.values());
            inFlight.clear();
        }
        for (PluginCall c : calls) {
            JSObject r = new JSObject();
            r.put("interrupted", true);
            c.resolve(r);
        }
    }

    /** Run now if the engine is initialised, queue if pending, reject if failed. */
    private void whenReady(PluginCall call, Runnable action) {
        boolean runNow = false;
        synchronized (lock) {
            if (state == PENDING) {
                queued.add(() -> whenReady(call, action));
            } else {
                runNow = true;
            }
        }
        if (!runNow) {
            return;
        }
        if (state == FAILED || tts == null) {
            call.reject("No text-to-speech engine is available on this device");
        } else {
            try {
                action.run();
            } catch (Exception e) {
                call.reject("Speech failed: " + e.getMessage());
            }
        }
    }

    @PluginMethod
    public void speak(final PluginCall call) {
        final String text = call.getString("text", "");
        if (text == null || text.trim().isEmpty()) {
            call.resolve(new JSObject());
            return;
        }
        whenReady(call, () -> {
            // Anything still speaking is about to be flushed; settle it first
            settleAllInterrupted();

            String lang = call.getString("lang", "");
            if (lang != null && !lang.isEmpty()) {
                try {
                    tts.setLanguage(Locale.forLanguageTag(lang));
                } catch (Exception ignored) { }
            }
            String voiceName = call.getString("voice", null);
            if (voiceName != null && !voiceName.isEmpty()) {
                try {
                    for (Voice v : tts.getVoices()) {
                        if (voiceName.equals(v.getName())) {
                            tts.setVoice(v);
                            break;
                        }
                    }
                } catch (Exception ignored) { }
            }
            float rate = clamp(call.getFloat("rate", 1.0f), 0.1f, 4.0f);
            float pitch = clamp(call.getFloat("pitch", 1.0f), 0.1f, 2.0f);
            float volume = clamp(call.getFloat("volume", 1.0f), 0.0f, 1.0f);
            tts.setSpeechRate(rate);
            tts.setPitch(pitch);

            String uid = call.getString("utteranceId", null);
            synchronized (lock) {
                if (uid == null || uid.isEmpty()) {
                    uid = "os-utt-" + (++counter);
                }
                inFlight.put(uid, call);
            }
            Bundle params = new Bundle();
            params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume);

            int res = tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, uid);
            if (res != TextToSpeech.SUCCESS) {
                PluginCall c = takeCall(uid);
                if (c != null) {
                    c.reject("The speech engine refused to start");
                }
            }
        });
    }

    @PluginMethod
    public void stop(PluginCall call) {
        try {
            if (tts != null) {
                tts.stop();
            }
        } catch (Exception ignored) { }
        settleAllInterrupted();
        call.resolve();
    }

    @PluginMethod
    public void getSupportedVoices(final PluginCall call) {
        whenReady(call, () -> {
            JSArray voices = new JSArray();
            try {
                for (Voice v : tts.getVoices()) {
                    if (v == null) {
                        continue;
                    }
                    JSObject o = new JSObject();
                    String name = v.getName();
                    o.put("voiceURI", name);
                    o.put("name", name);
                    Locale loc = v.getLocale();
                    o.put("lang", loc != null ? loc.toLanguageTag() : "");
                    o.put("localService", !v.isNetworkConnectionRequired());
                    o.put("default", false);
                    voices.put(o);
                }
            } catch (Exception ignored) {
                // Some engines throw while enumerating; return what we have
            }
            JSObject out = new JSObject();
            out.put("voices", voices);
            call.resolve(out);
        });
    }

    private static float clamp(Float v, float lo, float hi) {
        float f = (v == null) ? 1.0f : v;
        return Math.max(lo, Math.min(hi, f));
    }

    @Override
    protected void handleOnDestroy() {
        try {
            if (tts != null) {
                tts.stop();
                tts.shutdown();
            }
        } catch (Exception ignored) { }
        super.handleOnDestroy();
    }
}
