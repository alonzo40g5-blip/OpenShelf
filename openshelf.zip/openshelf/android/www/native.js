/* OpenShelf Android — native enhancements
 * Loaded only inside the Android (Capacitor) app, on top of the shared web reader.
 * The browser version ignores this file (it isn't referenced there).
 *
 * Adds things a plain website can't do:
 *   - Hardware VOLUME keys turn the page
 *   - Native status-bar colour that follows the reading theme
 *   - Android hardware BACK button closes the open book / sheet first
 */
(function () {
  function ready(fn){ if (document.readyState !== "loading") fn(); else document.addEventListener("DOMContentLoaded", fn); }

  ready(function () {
    var Cap = window.Capacitor;
    if (!Cap || !Cap.isNativePlatform || !Cap.isNativePlatform()) return; // web build: do nothing

    var Plugins = Cap.Plugins || {};

    // 1) Volume-button page turns (requires @capacitor-community/volume-buttons)
    try {
      var VolumeButtons = Plugins.VolumeButtons;
      if (VolumeButtons && VolumeButtons.watchVolume) {
        VolumeButtons.watchVolume({ disableSystemVolumeHandler: true }, function (res) {
          var reader = document.getElementById("reader");
          if (!reader || !reader.classList.contains("open")) return;
          // dispatch the same arrow keys the reader already listens for
          var key = (res && res.direction === "up") ? "ArrowLeft" : "ArrowRight";
          document.dispatchEvent(new KeyboardEvent("keydown", { key: key }));
        });
      }
    } catch (e) {}

    // 2) Status bar follows the page theme
    function syncStatusBar() {
      try {
        var StatusBar = Plugins.StatusBar;
        if (!StatusBar) return;
        var reader = document.getElementById("reader");
        var dark = reader && reader.classList.contains("open") &&
                   (getComputedStyle(document.documentElement).getPropertyValue("--page-bg").trim().toLowerCase().indexOf("#0") === 0
                    || document.querySelector(".swatch.on[data-theme=night]")
                    || document.querySelector(".swatch.on[data-theme=dusk]"));
        StatusBar.setStyle({ style: dark ? "DARK" : "LIGHT" });
      } catch (e) {}
    }
    // re-sync when the theme sheet is used or a book opens/closes
    document.addEventListener("click", function (ev) {
      if (ev.target.closest("#themeRow") || ev.target.closest("#rClose") || ev.target.closest(".bookcard")) {
        setTimeout(syncStatusBar, 60);
      }
    });
    setTimeout(syncStatusBar, 300);

    // 3) Hardware back button: close sheet → close book → then default
    try {
      var App = Plugins.App;
      if (App && App.addListener) {
        App.addListener("backButton", function () {
          var sheet = document.getElementById("aaSheet");
          var reader = document.getElementById("reader");
          if (sheet && sheet.classList.contains("open")) { document.getElementById("backdrop").click(); return; }
          if (reader && reader.classList.contains("open")) { document.getElementById("rClose").click(); return; }
          App.exitApp();
        });
      }
    } catch (e) {}
  });
})();
