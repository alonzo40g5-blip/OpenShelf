/* OpenShelf Android — native enhancements
 * Loaded only inside the Android (Capacitor) app, on top of the shared web reader.
 * The browser version ignores this file (it isn't referenced there).
 *
 * Adds things a plain website can't do:
 *   - Hardware VOLUME keys turn the page while a book is open
 *   - Native status-bar colour that follows the reading theme
 *   - Android hardware BACK button closes the open book / sheet first
 *   - Read-aloud through the device's real TTS engine (Samsung/Google voices)
 *
 * Both native features are backed by the app's OWN vendored plugins
 * (android/native-src/*.java) — no third-party npm plugins.
 */
(function () {
  function ready(fn){ if (document.readyState !== "loading") fn(); else document.addEventListener("DOMContentLoaded", fn); }

  ready(function () {
    var Cap = window.Capacitor;
    if (!Cap || !Cap.isNativePlatform || !Cap.isNativePlatform()) return; // web build: do nothing

    var Plugins = Cap.Plugins || {};

    // 1) Volume-button page turns (vendored VolumeButtonsPlugin.java).
    //    Keys are only captured while a book is open; everywhere else the
    //    volume buttons keep changing the volume as normal.
    try {
      var VolumeButtons = Plugins.VolumeButtons;
      if (VolumeButtons && VolumeButtons.watchVolume) {
        VolumeButtons.watchVolume({ disableSystemVolumeHandler: false }, function (res) {
          var reader = document.getElementById("reader");
          if (!reader || !reader.classList.contains("open")) return;
          // dispatch the same arrow keys the reader already listens for
          var key = (res && res.direction === "up") ? "ArrowLeft" : "ArrowRight";
          document.dispatchEvent(new KeyboardEvent("keydown", { key: key }));
        });
        // Capture volume keys only while the reader is open
        var readerEl = document.getElementById("reader");
        function syncCapture(){
          var open = !!(readerEl && readerEl.classList.contains("open"));
          try { VolumeButtons.setSuppressVolume({ enabled: open }); } catch (e) {}
        }
        if (readerEl && window.MutationObserver) {
          new MutationObserver(syncCapture).observe(readerEl, { attributes: true, attributeFilter: ["class"] });
        }
        syncCapture();
      }
    } catch (e) {}

    // 2) Status bar follows the page theme
    function syncStatusBar() {
      try {
        var StatusBar = Plugins.StatusBar;
        if (!StatusBar) return;
        var reader = document.getElementById("reader");
        var dark = reader && reader.classList.contains("open") &&
                   (getComputedStyle(document.documentElement).getPropertyValue("--page-bg").trim().toLowerCase().indexOf("#0") === 0
                    || document.querySelector(".swatch.on[data-theme=night]")
                    || document.querySelector(".swatch.on[data-theme=dusk]"));
        StatusBar.setStyle({ style: dark ? "DARK" : "LIGHT" });
      } catch (e) {}
    }
    // re-sync when the theme sheet is used or a book opens/closes
    document.addEventListener("click", function (ev) {
      if (ev.target.closest("#themeRow") || ev.target.closest("#rClose") || ev.target.closest(".bookcard")) {
        setTimeout(syncStatusBar, 60);
      }
    });
    setTimeout(syncStatusBar, 300);

    // 3) Hardware back button: close sheet → close book → then default
    try {
      var App = Plugins.App;
      if (App && App.addListener) {
        App.addListener("backButton", function () {
          var sheet = document.getElementById("aaSheet");
          var reader = document.getElementById("reader");
          if (sheet && sheet.classList.contains("open")) { document.getElementById("backdrop").click(); return; }
          if (reader && reader.classList.contains("open")) { document.getElementById("rClose").click(); return; }
          App.exitApp();
        });
      }
    } catch (e) {}

    // 4) NATIVE read-aloud through the device engine (vendored TextToSpeechPlugin.java).
    //    The WebView's own speechSynthesis is unreliable on many Android builds,
    //    so we replace it with one backed by the native plugin. The reader's
    //    existing play / voice / speed controls work unchanged.
    try {
      var TTS = Plugins.TextToSpeech;
      if (TTS && TTS.speak) {
        var seq = 0;

        // Plain, fully-controllable utterance type
        window.SpeechSynthesisUtterance = function (t) {
          this.text = t || ""; this.rate = 1; this.pitch = 1; this.volume = 1;
          this.voice = null; this.lang = ""; this.onstart = null; this.onend = null; this.onerror = null;
        };

        var nativeSynth = {
          _voices: [],
          _cur: null,           // the utterance we're currently speaking
          onvoiceschanged: null,
          getVoices: function () { return this._voices; },
          speak: function (u) {
            u._id = "os-js-" + (++seq);
            u._cancelled = false;
            nativeSynth._cur = u;
            var opts = {
              text: String(u.text || ""),
              rate: (u.rate || 1),
              pitch: (u.pitch || 1),
              volume: 1.0,
              lang: (u.voice && u.voice.lang) || u.lang || "en-US",
              utteranceId: u._id
            };
            if (u.voice && u.voice.name) opts.voice = u.voice.name;
            // Native speak() resolves only when the utterance FINISHES
            // ({interrupted:true} if it was cancelled/flushed) and rejects if
            // speech can't start — so genuine failures surface through onerror
            // instead of playing silence.
            TTS.speak(opts).then(function (res) {
              if (u._cancelled || nativeSynth._cur !== u) return;          // stale
              if (res && res.interrupted) return;                          // flushed by a newer utterance
              nativeSynth._cur = null;
              if (typeof u.onend === "function") u.onend();
            }).catch(function (e) {
              if (u._cancelled || nativeSynth._cur !== u) return;          // stale
              nativeSynth._cur = null;
              if (typeof u.onerror === "function") u.onerror(e);
            });
          },
          cancel: function () {
            var u = nativeSynth._cur;
            if (u) u._cancelled = true;
            nativeSynth._cur = null;
            try { TTS.stop(); } catch (e) {}
          },
          pause:  function () { nativeSynth.cancel(); },
          resume: function () {}
        };

        // Real "speech has started" signal from the engine → fires u.onstart,
        // which the reader uses to tell "starting slowly" apart from "broken".
        try {
          TTS.addListener("start", function (ev) {
            var u = nativeSynth._cur;
            if (u && ev && ev.utteranceId === u._id && !u._cancelled) {
              if (typeof u.onstart === "function") u.onstart();
            }
          });
        } catch (e) {}

        // Load the device's real voices for the picker (selection is by name)
        function loadNativeVoices() {
          TTS.getSupportedVoices().then(function (res) {
            var vs = (res && res.voices) || [];
            nativeSynth._voices = vs.map(function (v, i) {
              return { name: (v.name || v.voiceURI || ("Voice " + (i + 1))), lang: (v.lang || ""), "default": i === 0 };
            });
            if (typeof nativeSynth.onvoiceschanged === "function") nativeSynth.onvoiceschanged();
          }).catch(function () {});
        }

        // Install our engine in place of the WebView's
        try { Object.defineProperty(window, "speechSynthesis", { value: nativeSynth, configurable: true }); }
        catch (e) { try { window.speechSynthesis = nativeSynth; } catch (_) {} }
        loadNativeVoices();
        // The reader's own retry loop will re-read voices; also nudge it once more
        setTimeout(loadNativeVoices, 800);
      }
    } catch (e) {}
  });
})();
