/* OpenShelf Android — native enhancements
 * Loaded only inside the Android (Capacitor) app, on top of the shared web reader.
 * The browser version ignores this file (it isn't referenced there).
 *
 * Adds things a plain website can't do:
 *   - Hardware VOLUME keys turn the page
 *   - Native status-bar colour that follows the reading theme
 *   - Android hardware BACK button closes the open book / sheet first
 */
(function () {
  function ready(fn){ if (document.readyState !== "loading") fn(); else document.addEventListener("DOMContentLoaded", fn); }

  ready(function () {
    var Cap = window.Capacitor;
    if (!Cap || !Cap.isNativePlatform || !Cap.isNativePlatform()) return; // web build: do nothing

    var Plugins = Cap.Plugins || {};

    // 1) Volume-button page turns (requires @capacitor-community/volume-buttons)
    try {
      var VolumeButtons = Plugins.VolumeButtons;
      if (VolumeButtons && VolumeButtons.watchVolume) {
        VolumeButtons.watchVolume({ disableSystemVolumeHandler: true }, function (res) {
          var reader = document.getElementById("reader");
          if (!reader || !reader.classList.contains("open")) return;
          // dispatch the same arrow keys the reader already listens for
          var key = (res && res.direction === "up") ? "ArrowLeft" : "ArrowRight";
          document.dispatchEvent(new KeyboardEvent("keydown", { key: key }));
        });
      }
    } catch (e) {}

    // 2) Status bar follows the page theme
    function syncStatusBar() {
      try {
        var StatusBar = Plugins.StatusBar;
        if (!StatusBar) return;
        var reader = document.getElementById("reader");
        var dark = reader && reader.classList.contains("open") &&
                   (getComputedStyle(document.documentElement).getPropertyValue("--page-bg").trim().toLowerCase().indexOf("#0") === 0
                    || document.querySelector(".swatch.on[data-theme=night]")
                    || document.querySelector(".swatch.on[data-theme=dusk]"));
        StatusBar.setStyle({ style: dark ? "DARK" : "LIGHT" });
      } catch (e) {}
    }
    // re-sync when the theme sheet is used or a book opens/closes
    document.addEventListener("click", function (ev) {
      if (ev.target.closest("#themeRow") || ev.target.closest("#rClose") || ev.target.closest(".bookcard")) {
        setTimeout(syncStatusBar, 60);
      }
    });
    setTimeout(syncStatusBar, 300);

    // 3) Hardware back button: close sheet → close book → then default
    try {
      var App = Plugins.App;
      if (App && App.addListener) {
        App.addListener("backButton", function () {
          var sheet = document.getElementById("aaSheet");
          var reader = document.getElementById("reader");
          if (sheet && sheet.classList.contains("open")) { document.getElementById("backdrop").click(); return; }
          if (reader && reader.classList.contains("open")) { document.getElementById("rClose").click(); return; }
          App.exitApp();
        });
      }
    } catch (e) {}

    // 4) NATIVE read-aloud through the device engine (Samsung/Google TTS).
    //    The WebView's own speechSynthesis is unreliable on many Android builds,
    //    so we replace it with one backed by @capacitor-community/text-to-speech.
    try {
      var TTS = Plugins.TextToSpeech;
      if (TTS && TTS.speak) {
        // Force a plain, fully-controllable utterance type
        window.SpeechSynthesisUtterance = function (t) {
          this.text = t || ""; this.rate = 1; this.pitch = 1; this.volume = 1;
          this.voice = null; this.lang = ""; this.onstart = null; this.onend = null; this.onerror = null;
        };
        var nativeSynth = {
          _voices: [],
          onvoiceschanged: null,
          getVoices: function () { return this._voices; },
          speak: function (u) {
            var opts = {
              text: String(u.text || ""),
              rate: (u.rate || 1),
              pitch: (u.pitch || 1),
              volume: 1.0,
              lang: (u.voice && u.voice.lang) || u.lang || "en-US",
              category: "playback"
            };
            if (u.voice && typeof u.voice._idx === "number") opts.voice = u.voice._idx;
            // Native speak() resolves only when finished, rejects if it can't start.
            // We deliberately do NOT fire onstart optimistically, so a genuine
            // failure surfaces through onerror instead of playing silence.
            TTS.speak(opts).then(function () {
              if (typeof u.onend === "function") u.onend();
            }).catch(function (e) {
              if (typeof u.onerror === "function") u.onerror(e);
            });
          },
          cancel: function () { try { TTS.stop(); } catch (e) {} },
          pause:  function () { try { TTS.stop(); } catch (e) {} },
          resume: function () {}
        };
        // Load the device's real voices for the picker
        function loadNativeVoices() {
          TTS.getSupportedVoices().then(function (res) {
            var vs = (res && res.voices) || [];
            nativeSynth._voices = vs.map(function (v, i) {
              return { name: (v.name || v.voiceURI || ("Voice " + (i + 1))), lang: (v.lang || ""), "default": i === 0, _idx: i };
            });
            if (typeof nativeSynth.onvoiceschanged === "function") nativeSynth.onvoiceschanged();
          }).catch(function () {});
        }
        // Install our engine in place of the WebView's
        try { Object.defineProperty(window, "speechSynthesis", { value: nativeSynth, configurable: true }); }
        catch (e) { try { window.speechSynthesis = nativeSynth; } catch (_) {} }
        loadNativeVoices();
        // The reader's own retry loop will re-read voices; also nudge it once more
        setTimeout(loadNativeVoices, 800);
      }
    } catch (e) {}
  });
})();
